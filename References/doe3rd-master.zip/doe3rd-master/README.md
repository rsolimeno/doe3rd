# doe3rd
DOE 3rd Edition
